const suma = (a:number, b: number ): number =>{
    return a+b;
};